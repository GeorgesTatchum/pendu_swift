//
//  ViewController.swift
//  pendu_td3
//
//  Created by Georges Gaetan Tatchum Fotso on 20/03/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let pendu_sender = sender as! UIButton
        let pendu_controller = segue.destination as! PenduViewController
        
        pendu_controller.niveau = pendu_sender.tag
    }


}

