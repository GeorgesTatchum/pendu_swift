//
//  PenduViewController.swift
//  pendu_td3
//
//  Created by Georges Gaetan Tatchum Fotso on 20/03/2024.
//

import UIKit

class PenduViewController: UIViewController {
    
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var vignette: UIImageView!
    @IBOutlet weak var mot: UILabel!
    @IBOutlet var bouttons: [UIButton]!
    
    func finPartie(_ chaine : String){
        message.text = chaine;
        for b in bouttons{
            b.isEnabled = false
        }
    }
    
    var niveau = 1
    var first = 0
    var last = 0
    let dictionnaire : [String] = ["PREMIER", "SECOND", "BONJOUR", "SECRET"]
    var lettreATrouver: String = "";
    var tailleLettreATrouver: Int = 0;
    var trouver : Bool = false;
    var etape: Int = 0;
    
    @IBAction func clic(_ sender: UIButton) {
        let lettre = sender.titleLabel?.text ?? ""
        print("la lettre choisi est  : \(Character(lettre))")
        sender.isEnabled = false
        var y = 0
        var tab_lettreATrouver : [Character] = []
        for l in mot.text! {
            if l != " "{
                tab_lettreATrouver.append(l)
            }
            
        }
        for l in lettreATrouver{
            if y >= first && y <= last {
                if l == Character(lettre) {
                    tab_lettreATrouver[y] = Character(lettre)
                    tailleLettreATrouver -= 1
                    trouver = true
                    print("tailleLettreATrouver \(tailleLettreATrouver)")
                    if tailleLettreATrouver == 0 {
                        print("vous avez perdu")
                        finPartie("Gagné")
                    }
                }
            }
            y += 1
        }
        if !trouver {
            etape += 1
            vignette.image = UIImage(named: "pendu\(etape)")
            if etape == 11 {
                finPartie("Perdu")
                print("vous avez perdu")
            }
        }
        mot.text = ""
        for l in tab_lettreATrouver {
            mot.text! += String(l)
        }
            
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("le niveau de jeu est  : \(self.niveau)")
        // Do any additional setup after loading the view.
        lettreATrouver = dictionnaire.randomElement()!
        print("le mot secret  : \(lettreATrouver)")
        
        mot.text = ""
        
        switch niveau {
        case 1: first = 1; last = lettreATrouver.count - 2
        case 2: first = 1; last = lettreATrouver.count - 1
        case 3: first = 0; last = lettreATrouver.count - 1
        default: break
        }
        var i = 0
        for l in lettreATrouver {
            if i <= last && i >= first {
                mot.text! += "_ "
            } else {
                mot.text! += String(l)
            }
            
            i += 1
        }
        tailleLettreATrouver = last - first + 1
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
